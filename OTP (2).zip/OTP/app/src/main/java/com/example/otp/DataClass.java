package com.example.otp;

public class DataClass {
    private String datatitle;
    private String datadesc;
    private String dataimage;
    private String Key;

    public String getKey() {
        return Key;
    }

    public void setKey(String key) {
        Key = key;
    }

    public String getDatatitle() {
        return datatitle;
    }

    public String getDatadesc() {
        return datadesc;
    }

    public String getDataimage() {
        return dataimage;
    }

    public DataClass(String datatitle, String datadesc, String dataimage) {
        this.datatitle = datatitle;
        this.datadesc = datadesc;
        this.dataimage = dataimage;
    }
    public DataClass(){

    }
}
