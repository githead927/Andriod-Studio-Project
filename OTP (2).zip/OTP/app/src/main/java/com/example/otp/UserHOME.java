package com.example.otp;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.UserHandle;
import android.provider.ContactsContract;
import android.text.Layout;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class UserHOME extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    static final float END_SCALE = 0.7f;
    RecyclerView featuredrecycler, featuredrecycler2;
    RecyclerView.Adapter adapter2;
    LinearLayout contentView;
    private long backPressedTime;

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    ImageView menuicon;

    RecyclerView recyclerView;
    List<DataClass> datalist;
    DatabaseReference databaseReference;
    ValueEventListener eventListener;
    MyAdapter adapter;

    ImageView Feedbackimg;
    FirebaseAnalytics analytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_user_home);

        analytics = FirebaseAnalytics.getInstance(this);


        featuredrecycler2 = findViewById(R.id.featured_recycler2);
        featuredrecycler2();

        contentView = findViewById(R.id.content);

        Feedbackimg = findViewById(R.id.feedbackimg);
        Feedbackimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showdialog();
            }
        });

        //Home Menu
        drawerLayout = findViewById(R.id.layout_drawer);
        navigationView = findViewById(R.id.nav_navigationview);
        menuicon = findViewById(R.id.navigation_bar_icon);

        navigationDrawer();

        recyclerView = findViewById(R.id.featured_recycler);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(UserHOME.this,1);
        recyclerView.setLayoutManager(gridLayoutManager);

        AlertDialog.Builder builder = new AlertDialog.Builder(UserHOME.this);
        builder.setCancelable(false);
        builder.setView(R.layout.progress);
        AlertDialog dialog = builder.create();
        dialog.show();

        datalist = new ArrayList<>();
        adapter = new MyAdapter(UserHOME.this,datalist);
        recyclerView.setAdapter(adapter);
        databaseReference = FirebaseDatabase.getInstance().getReference("Bikes");
        dialog.show();

        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                datalist.clear();
                for (DataSnapshot itemSnapshot : snapshot.getChildren()) {
                    DataClass dataClass = itemSnapshot.getValue(DataClass.class);
                    datalist.add(dataClass);
                }

                adapter.notifyDataSetChanged();
                dialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialog.dismiss();
            }

        });
    }
    //navigation Drawer functions
    private void navigationDrawer() {
        navigationView.bringToFront();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_home);

        menuicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (drawerLayout.isDrawerVisible(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                } else
                    drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        animateNavigationDrawer();

    }

    private void animateNavigationDrawer() {
        drawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {
                final float diffScaled = slideOffset * (1 - END_SCALE);
                final float offsetScale = 1 - diffScaled;
                contentView.setScaleX(offsetScale);
                contentView.setScaleY(offsetScale);

                final float xOffset = drawerView.getWidth() * slideOffset;
                final float xOffsetDiff = contentView.getWidth() * diffScaled / 2;
                final float xTranslation = xOffset - xOffsetDiff;
                contentView.setTranslationX(xTranslation);
            }

            @Override
            public void onDrawerOpened(@NonNull View drawerView) {

            }

            @Override
            public void onDrawerClosed(@NonNull View drawerView) {

            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }
        });
    }
    @Override
    public void onBackPressed() {
        if(backPressedTime +2000 > System.currentTimeMillis()){//comparing time between first pressed back and second time;
            finish();
            super.onBackPressed();
            return;
        }else{
            Toast.makeText(getBaseContext(),"Press back again to exit",Toast.LENGTH_SHORT).show();
        }
        backPressedTime = System.currentTimeMillis();
    }

    //Recycler cardview functions
    private void featuredrecycler2() {
        featuredrecycler2.setHasFixedSize(true);
        featuredrecycler2.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        ArrayList<FeaturedHelperClass2> featuredlocations2 = new ArrayList<>();

        featuredlocations2.add(new FeaturedHelperClass2("Choose Your Vehicle", "Select the one you want to rent using the catalogue."));
        featuredlocations2.add(new FeaturedHelperClass2("Choose Your Package", "Fill the form with your booking details."));
        featuredlocations2.add(new FeaturedHelperClass2("Enjoy Your Ride", "Be flexible with our multiple rental locations"));

        adapter2 = new FeaturedAdapter2(featuredlocations2);
        featuredrecycler2.setAdapter(adapter2);
    }

    public void showdialog(){
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Feedback Form");
        dialog.setMessage("Provide us your valuable feedback");

        LayoutInflater inflate = LayoutInflater.from(this);

        View reg_layout = inflate.inflate(R.layout.activity_feedback,null);
        final EditText edtEmail = reg_layout.findViewById(R.id.edtEmail);
        final EditText edtName = reg_layout.findViewById(R.id.edtName);
        final EditText edtFeedback = reg_layout.findViewById(R.id.edtFeedback);

        dialog.setView(reg_layout);

        dialog.setPositiveButton("SEND", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if(TextUtils.isEmpty(edtEmail.getText().toString())){
                    Toast.makeText(UserHOME.this, "Provide valid EMAIL", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(edtName.getText().toString())){
                    Toast.makeText(UserHOME.this, "Provide NAME", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(edtFeedback.getText().toString())){
                    Toast.makeText(UserHOME.this, "Provide FEEDBACK", Toast.LENGTH_SHORT).show();
                    return;
                }

                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference();

                myRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(UserHOME.this, "Failed!!", Toast.LENGTH_SHORT).show();
                    }
                });
                myRef.child("FeedBacks").child(edtName.getText().toString()).child("Email").setValue(edtEmail.getText().toString());
                myRef.child("FeedBacks").child(edtName.getText().toString()).child("Feedback").setValue(edtFeedback.getText().toString());
                myRef.child("FeedBacks").child(edtName.getText().toString()).child("Name").setValue(edtName.getText().toString());

                Toast.makeText(UserHOME.this, "Thank You for the feedback", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        dialog.show();
    }



    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_home:
                if (drawerLayout.isDrawerVisible(GravityCompat.START))
                    drawerLayout.closeDrawer(GravityCompat.START);
                break;
            case R.id.nav_logout:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(UserHOME.this, login.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.stay);
                break;
            case R.id.nav_feedback:
                startActivity(new Intent(UserHOME.this,FEEDBACK.class));
                Toast.makeText(this, "Feedback", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_share:
                Intent sendintent = new Intent();
                sendintent.setAction(Intent.ACTION_SEND);
                sendintent.putExtra(Intent.EXTRA_TEXT, "Hey check out my app at: https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID);
                sendintent.setType("plain/text");
                startActivity(sendintent);
                break;
            case R.id.nav_rateus:
                rate_usdialog rateUsdialog = new rate_usdialog(UserHOME.this);
                rateUsdialog.getWindow().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.white)));
                rateUsdialog.setCancelable(false);
                rateUsdialog.show();
                break;
            /*case R.id.nav_profile:
                startActivity(new Intent(UserHOME.this,UserProfileActivity.class));
                Toast.makeText(this, "User Profile", Toast.LENGTH_SHORT).show();
                break;*/

        }
        return true;
    }
}