package com.example.otp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;

public class FEEDBACK extends Dialog {

    public FEEDBACK(@NonNull Context context) {
        super(context);
    }

    public FEEDBACK(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    protected FEEDBACK(@NonNull Context context, boolean cancelable, @Nullable OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);


    }


}