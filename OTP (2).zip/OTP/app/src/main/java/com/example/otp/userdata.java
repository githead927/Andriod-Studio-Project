package com.example.otp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class userdata extends AppCompatActivity {
    RecyclerView recyclerView;
    List<DataClass> datalist;
    List<Customer> customerList;
    DatabaseReference databaseReference;
    ValueEventListener eventListener;
    SearchView searchView;
    MyAdapter adapter;


    ImageView arrowback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userdata);


        searchView = findViewById(R.id.search);
        searchView.clearFocus();


        arrowback = findViewById(R.id.arrow_back);
        arrowback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(userdata.this,admin_update.class);
                startActivity(intent);
            }
        });

        recyclerView = findViewById(R.id.recuserdata);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(userdata.this,1);
        recyclerView.setLayoutManager(gridLayoutManager);

        AlertDialog.Builder builder = new AlertDialog.Builder(userdata.this);
        builder.setCancelable(false);
        builder.setView(R.layout.progress);
        AlertDialog dialog = builder.create();
        dialog.show();

        customerList = new ArrayList<>();
        MyAdapter3 adapter3 = new MyAdapter3(userdata.this,customerList);
        recyclerView.setAdapter(adapter3);

        databaseReference = FirebaseDatabase.getInstance().getReference("Booked");
        dialog.show();

        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                customerList.clear();
                for(DataSnapshot itemSnapshot: snapshot.getChildren()){
                    Customer customerclass = itemSnapshot.getValue(Customer.class);
                    customerList.add(customerclass);
                }
                adapter3.notifyDataSetChanged();
                dialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialog.dismiss();
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                //searchList(newText);
                return true;
            }
        });
    }

    /*public void searchList(String text){
        ArrayList<DataClass> searchList = new ArrayList<>();
        for(DataClass dataclass: datalist){
            if(dataclass.getDatatitle().toLowerCase().contains(text.toLowerCase())){
                searchList.add(dataclass);
            }
        }
        adapter.searchDataList(searchList);
    }*/

}