package com.example.otp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter2 extends RecyclerView.Adapter<MyViewHolder2> {
    private Context context;
    private List<DataClass> dataClassList;

    public MyAdapter2(Context context, List<DataClass> dataClassList) {
        this.context = context;
        this.dataClassList = dataClassList;
    }

    @NonNull
    @Override
    public MyViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item,parent,false);
        return new MyViewHolder2(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder2 holder, int position) {
        Glide.with(context).load(dataClassList.get(position).getDataimage()).into(holder.recImage);
        holder.recName.setText(dataClassList.get(position).getDatatitle());
        holder.recDesc.setText(dataClassList.get(position).getDatatitle());
        holder.recCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context,DetailActivity2.class);
                intent.putExtra("Image",dataClassList.get(holder.getAdapterPosition()).getDataimage());
                intent.putExtra("Name",dataClassList.get(holder.getAdapterPosition()).getDatatitle());
                intent.putExtra("Desc",dataClassList.get(holder.getAdapterPosition()).getDatadesc());
                intent.putExtra("Key",dataClassList.get(holder.getAdapterPosition()).getKey());

                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return dataClassList.size();
    }

    public void searchDataList(ArrayList<DataClass> searchList) {
        dataClassList = searchList;
        notifyDataSetChanged();
    }
}

class MyViewHolder2 extends RecyclerView.ViewHolder{
    ImageView recImage;
    TextView recName,recDesc;
    CardView recCard;

    public MyViewHolder2(@NonNull View itemView) {
        super(itemView);

        recImage = itemView.findViewById(R.id.recImage);
        recName = itemView.findViewById(R.id.recName);
        recDesc = itemView.findViewById(R.id.recDesc);
        recCard = itemView.findViewById(R.id.recCard);
    }
}
