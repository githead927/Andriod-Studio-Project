package com.example.otp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.github.clans.fab.FloatingActionButton;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Calendar;

public class DetailActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {
    ImageView image,report;
    TextView txtnames,txtdesc;
    FloatingActionButton deleteButton,editbutton;
    String key = "";
    String imageUrl = "";
    Button bikeselect;
    private EditText ed1,ed2,ed3,ed4,ed5;
    private TextView t1,txt1;
    private FirebaseDatabase dB;
    private DatabaseReference dR;
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener firebaseAuthListener;
    public static final String DATABASE_PATH_FB = "Booked";
    private FirebaseUser user;
    private ImageView img1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        //Define firebase instances
        firebaseAuth = FirebaseAuth.getInstance();
        dB = FirebaseDatabase.getInstance();
        dR = dB.getReference(DATABASE_PATH_FB);
        user=firebaseAuth.getCurrentUser();

        //Checking user login
        firebaseAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(user == null){
                    finish();
                    FirebaseAuth.getInstance().signOut();
                    startActivity(new Intent(getApplicationContext(),Registration.class));
                }
            }
        };



        //Define layout objects
        img1 = findViewById(R.id.datepicker1); //Image
        ed1 = findViewById(R.id.editText8); //Full name
        ed2 = findViewById(R.id.editText10); //phone
        ed3 = findViewById(R.id.editText7); //time
        t1 = findViewById(R.id.editText6); //booking date
        ed5 = findViewById(R.id.editText5); //license
        image = findViewById(R.id.detailimage);
        txtnames = findViewById(R.id.detailname);
        txtdesc = findViewById(R.id.detaildesc);
        deleteButton = findViewById(R.id.deletebutton);
        editbutton = findViewById(R.id.editbutton);
        report = findViewById(R.id.reportgeneration);

        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog();
            }
        });
        //bikeselect = findViewById(R.id.bike_select);

        /*bikeselect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(DetailActivity.this, "Bike selected", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(DetailActivity.this,Bookcar.class));
            }
        });*/



        Bundle bundle = getIntent().getExtras();
        if(bundle!=null){
            txtdesc.setText(bundle.getString("Desc"));
            txtnames.setText(bundle.getString("Name"));
            key = bundle.getString("Key");
            imageUrl = bundle.getString("Image");
            Glide.with(this).load(bundle.getString("Image")).into(image);
        }
        /*deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Bikes");
                FirebaseStorage storage = FirebaseStorage.getInstance();

                StorageReference storageReference = storage.getReferenceFromUrl(imageUrl);
                storageReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        databaseReference.child(key).removeValue();
                        Toast.makeText(DetailActivity.this,"Deleted",Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),admin_update.class));
                        finish();
                    }
                });
            }
        });
        editbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DetailActivity.this,UpdateActivity.class);
                intent.putExtra("Name",txtnames.getText().toString());
                intent.putExtra("Desc",txtdesc.getText().toString());
                intent.putExtra("Image",imageUrl);
                intent.putExtra("Key",key);
                startActivity(intent);
            }
        });*/


    }

    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        String date = "" + i + '-' + i1 + '-' + i2;
        t1.setText(date);
    }
    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                this,
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.YEAR)
        );
        datePickerDialog.show();

    }
    public void Cancel(View v){
        finish();
        startActivity(new Intent(DetailActivity.this,UserHOME.class));
    }
    public void rentNow(View v){
        String bikename = txtnames.getText().toString().trim();
        String fullname = ed1.getText().toString().trim();
        String contact = ed2.getText().toString().trim();
        String usetime = ed3.getText().toString().trim();
        String bookingTime = t1.getText().toString().trim();
        String licenceNumber = ed5.getText().toString().trim();

        if(TextUtils.isEmpty(fullname)){
            ed1.setError("Please input your name");
        }
        if(TextUtils.isEmpty(contact)){
            ed2.setError("Please input your contact number");
        }
        if(TextUtils.isEmpty(usetime)){
            ed3.setError("Please input booking time");
        }
        if(TextUtils.isEmpty(bookingTime)){
            t1.setError("Please input your booking Date");
        }
        if(TextUtils.isEmpty(licenceNumber)){
            ed5.setError("Please put your licence number");
        }

        if(!TextUtils.isEmpty(fullname)
                && !TextUtils.isEmpty(contact)
                && !TextUtils.isEmpty(usetime)
                && !TextUtils.isEmpty(bookingTime)
                && !TextUtils.isEmpty(licenceNumber)){
            //Upload data
            String savedID = dR.push().getKey();
            dR = dB.getReference(DATABASE_PATH_FB);
            Customer customer = new Customer(fullname,contact,usetime,bookingTime,licenceNumber,bikename);
            dR.child(savedID).setValue(customer);
            Toast.makeText(this, "Successful Book", Toast.LENGTH_SHORT).show();
            finish();
            Intent intent = new Intent(DetailActivity.this,UserHOME.class);
            startActivity(intent);
        }
    }

    protected void onStart(){
        super.onStart();
        firebaseAuth.addAuthStateListener(firebaseAuthListener);
    }

    protected void onStop(){
        super.onStop();
        if(firebaseAuthListener != null){
            firebaseAuth.removeAuthStateListener(firebaseAuthListener);
        }
        /*report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(DetailActivity.this, "Report", Toast.LENGTH_SHORT).show();
            }
        });*/
    }
}