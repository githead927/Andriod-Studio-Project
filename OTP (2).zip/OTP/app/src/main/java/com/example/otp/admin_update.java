package com.example.otp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class admin_update extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    static final float END_SCALE = 0.7f;
    NavigationView navigationview;
    DrawerLayout drawerLayout1;
    ImageView menuicon,report_generate;
    LinearLayout contentView1;

    FloatingActionButton fab;
    RecyclerView recyclerView;
    List<DataClass> datalist;
    ValueEventListener eventListener;
    DatabaseReference databaseReference;
    SearchView searchView;
    MyAdapter2 adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_update);
        
        navigationview = findViewById(R.id.nav_navigationview1);
        menuicon = findViewById(R.id.navigation_bar_icon1);
        drawerLayout1 = findViewById(R.id.layout_drawer1);

        searchView = findViewById(R.id.search);
        searchView.clearFocus();
        report_generate = findViewById(R.id.reportgeneration);
        report_generate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(admin_update.this, "Report genrate", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(admin_update.this,userdata.class);
                startActivity(intent);
            }
        });

        fab = findViewById(R.id.fab_add);
        recyclerView = findViewById(R.id.recycler_view);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(admin_update.this,1);
        recyclerView.setLayoutManager(gridLayoutManager);
        AlertDialog.Builder builder = new AlertDialog.Builder(admin_update.this);
        builder.setCancelable(false);
        builder.setView(R.layout.progress);
        AlertDialog dialog = builder.create();
        dialog.show();

        datalist = new ArrayList<>();
        adapter = new MyAdapter2(admin_update.this,datalist);
        recyclerView.setAdapter(adapter);

        databaseReference = FirebaseDatabase.getInstance().getReference("Bikes");
        dialog.show();

        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                datalist.clear();
                for(DataSnapshot itemsnapshot: snapshot.getChildren()){
                    DataClass dataClass = itemsnapshot.getValue(DataClass.class);
                    dataClass.setKey(itemsnapshot.getKey());
                    datalist.add(dataClass);
                }
                adapter.notifyDataSetChanged();
                dialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialog.dismiss();
            }
        });
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchList(newText);
                return false;
            }
        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin_update.this,UploadActivity.class);
                startActivity(intent);
            }
        });

        contentView1 = findViewById(R.id.content1);
        navigationDrawer();
    }

    public void searchList(String text){
        ArrayList<DataClass> searchList = new ArrayList<>();
        for(DataClass dataclass: datalist){
            if(dataclass.getDatatitle().toLowerCase().contains(text.toLowerCase())){
                searchList.add(dataclass);
            }
        }
        adapter.searchDataList(searchList);
    }

    private void navigationDrawer() {
        navigationview.bringToFront();
        navigationview.setNavigationItemSelectedListener(this);
        navigationview.setCheckedItem(R.id.nav_home);

        menuicon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (drawerLayout1.isDrawerVisible(GravityCompat.START)) {
                    drawerLayout1.closeDrawer(GravityCompat.START);
                } else
                    drawerLayout1.openDrawer(GravityCompat.START);
            }
        });
        animateNavigationDrawer();
    }

    private void animateNavigationDrawer() {
        drawerLayout1.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {
                final float diffScaled = slideOffset * (1 - END_SCALE);
                final float offsetScale = 1 - diffScaled;
                contentView1.setScaleX(offsetScale);
                contentView1.setScaleY(offsetScale);

                final float xOffset = drawerView.getWidth() * slideOffset;
                final float xOffsetDiff = contentView1.getWidth() * diffScaled / 2;
                final float xTranslation = xOffset - xOffsetDiff;
                contentView1.setTranslationX(xTranslation);
            }

            @Override
            public void onDrawerOpened(@NonNull View drawerView) {

            }

            @Override
            public void onDrawerClosed(@NonNull View drawerView) {

            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }
        });
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_home:
                if (drawerLayout1.isDrawerVisible(GravityCompat.START))
                    drawerLayout1.closeDrawer(GravityCompat.END);
            case R.id.nav_logout:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(admin_update.this, login.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.stay);
                break;
            case R.id.nav_feedback:
                Toast.makeText(this, "Feedback", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_share:
                Intent sendintent = new Intent();
                sendintent.setAction(Intent.ACTION_SEND);
                sendintent.putExtra(Intent.EXTRA_TEXT, "Hey check out my app at: https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID);
                sendintent.setType("plain/text");
                startActivity(sendintent);
                break;
            case R.id.nav_rateus:
                rate_usdialog rateUsdialog = new rate_usdialog(admin_update.this);
                rateUsdialog.getWindow().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.white)));
                rateUsdialog.setCancelable(false);
                rateUsdialog.show();
                break;
        }
        return true;
    }
}