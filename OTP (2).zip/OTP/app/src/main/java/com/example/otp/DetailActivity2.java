package com.example.otp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.github.clans.fab.FloatingActionButton;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class DetailActivity2 extends AppCompatActivity {
    TextView detailname,detaildesc;
    ImageView detailimage;
    String key = "";
    String imageUrl = "";
    FloatingActionButton deleteButton,editbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail2);

        detailname = findViewById(R.id.detailname1);
        detailimage = findViewById(R.id.detailimage1);
        detaildesc = findViewById(R.id.detaildesc1);
        deleteButton = findViewById(R.id.deletebutton);
        editbutton = findViewById(R.id.editbutton);

        Bundle bundle = getIntent().getExtras();
        if(bundle!=null) {
            detaildesc.setText(bundle.getString("Desc"));
            detailname.setText(bundle.getString("Name"));
            key = bundle.getString("Key");
            imageUrl = bundle.getString("Image");
            Glide.with(this).load(bundle.getString("Image")).into(detailimage);

        }
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Bikes");
                FirebaseStorage storage = FirebaseStorage.getInstance();

                StorageReference storageReference = storage.getReferenceFromUrl(imageUrl);
                storageReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        databaseReference.child(key).removeValue();
                        Toast.makeText(DetailActivity2.this,"Deleted",Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),admin_update.class));
                        finish();
                    }
                });
            }
        });
        editbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DetailActivity2.this,UpdateActivity.class);
                intent.putExtra("Name",detailname.getText().toString());
                intent.putExtra("Desc",detaildesc.getText().toString());
                intent.putExtra("Image",imageUrl);
                intent.putExtra("Key",key);
                startActivity(intent);
            }
        });

    }
}