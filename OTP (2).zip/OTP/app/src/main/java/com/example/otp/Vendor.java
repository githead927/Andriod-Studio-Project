package com.example.otp;

public class Vendor {
    public String fullname,email;

    public Vendor(String fullname, String email) {
        this.fullname = fullname;
        this.email = email;
    }
}
