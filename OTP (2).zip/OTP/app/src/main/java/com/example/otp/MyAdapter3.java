package com.example.otp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter3 extends RecyclerView.Adapter<MyViewHolder3> {

    private Context context;
    private List<Customer> customerList;

    public MyAdapter3(Context context, List<Customer> customerList) {
        this.context = context;
        this.customerList = customerList;
    }

    @NonNull
    @Override
    public MyViewHolder3 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item2,parent,false);
        return new MyViewHolder3(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder3 holder, int position) {
        holder.cname.setText(customerList.get(position).getcName());
        holder.ccontact.setText(customerList.get(position).getcContact());
        holder.cbikename.setText(customerList.get(position).getDatatitle());
        holder.cbookingtime.setText(customerList.get(position).getcBookingtime());
        holder.cusetime.setText(customerList.get(position).getcUsetime());
        holder.clicence.setText(customerList.get(position).getcLicence());

        holder.cCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return customerList.size();
    }

    public void searchDataList2(ArrayList<Customer> searchlist){
        customerList = searchlist;
        notifyDataSetChanged();
    }


}

class MyViewHolder3 extends RecyclerView.ViewHolder{
    TextView cname,ccontact,cbikename,cbookingtime,cusetime,clicence;
    CardView cCard;

    public MyViewHolder3(@NonNull View itemView) {
        super(itemView);

        cname = itemView.findViewById(R.id.recClientName2);
        ccontact = itemView.findViewById(R.id.recClientContact2);
        cbikename = itemView.findViewById(R.id.recName2);
        cbookingtime = itemView.findViewById(R.id.recClientBookingTime2);
        cusetime = itemView.findViewById(R.id.recUsetime2);
        clicence = itemView.findViewById(R.id.recClientLicence2);

        cCard = itemView.findViewById(R.id.recItem);
    }
}
